﻿$(document).ready(function () {
    $("#email").focus();
    $("#contact").submit(function (e) {
        e.preventDefault();
    }).validate({
        rules: {
            name: {
                required: true,
            },
            email: {
                required: true,
                email: true
            },
            phone: {
                required: true,
                phoneUS: true
            },
            address1: {
                required: true
            },
            city: {
                required: true
            },
            state: {
                required: true,
                rangelength: [2, 2]
            },
            zip: {
                required: true,
                rangelength: [5, 5]
            },
            message: {
                required: true
            }
        },
        submitHandler: function (event) {
            location.href = "thanks.html";
        }
    });
});
