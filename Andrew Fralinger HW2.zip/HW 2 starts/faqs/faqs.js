window.onload = function () { //For some reason, I had to enable debugging to see any changes being made.
    var faqs = $("faqs");
    var h2Elements = faqs.getElementsByTagName("h2");

    var h2Node;
    for (var i = 0; i < h2Elements.length; i++) {
        h2Node = h2Elements[i];

        // Attach event handler
        h2Node.onclick = function () {
            var h2 = this;         // h2 is the current headingNode object
            if (h2.hasAttribute("class")) {
                h2.removeAttribute("class");
            }
            else {
                h2.setAttribute("class", "minus");
                for (var x = 0; x < h2Elements.length; x++) {
                    if (h2Elements[x] != h2)
                        h2Elements[x].removeAttribute("class");
                }
            }
            if (h2.nextElementSibling.hasAttribute("class")) {
                h2.nextElementSibling.removeAttribute("class");
            }
            else {
                h2.nextElementSibling.setAttribute("class", "open");
                for (var y = 0; y < h2Elements.length; y++) {
                    if (h2Elements[y] != h2)
                        h2Elements[y].nextElementSibling.removeAttribute("class");
                }
            }
        }
    }
    $("first_link").focus();
}
var $ = function (id) {
	return document.getElementById(id);
}