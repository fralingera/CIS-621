var r1 = [1540, 1130, 1580, 1105];
var r2 = [2010, 1168, 2305, 4102];
var r3 = [2450, 1847, 2710, 2391];
var r4 = [1845, 1491, 1284, 1575];
var r5 = [2120, 1767, 1599, 3888];
var regions = [r1, r2, r3, r4, r5]; //An array I added in an attempt to make the region sales function a bit more dynamic.  Obviously, the real world would probably have each array in a database, but this will do for now.
var textDisplay;

var $ = function (id) {
	return document.getElementById(id);
}

var quarterSales = function () {
    //$("results").textContent = "quarter"; Used these lines to test that the buttons would do what I think they do.
    $("results").textContent = ""; //Clear any previous button presses first.
    $("results").textContent = "Sales by quarter" + "\n";
    var quarterTotals = [0, 0, 0, 0] //Initializing all to 0, to avoid any NaN troubles later.  I can use this static sized array, since there will only ever be 4 quarters in a year.
    for (var i = 0; i < 4; i++) {
        for (var j = 0; j < regions.length; j++) {
            quarterTotals[i] += (regions[j])[i];
        }
        $("results").textContent += "Quarter " + (i + 1) + ": " + quarterTotals[i] + "\n"; //Basically, this function is the reverse of the function below (This one was completed second).
    }
}

var regionSales = function () {
    //$("results").textContent = "region";
    $("results").textContent = ""; //Again, clearing button presses.
    $("results").textContent = "Sales by region" + "\n";
    var regionTotals = [];
    for (var x = 0; x < regions.length; x++) {
        regionTotals[x] = 0; //The initial value must be set at 0, or the result will come up NaN.  Again, doing it this way results in less lines of code, and can scale better.
        for (var y = 0; y < 4; y++) {
            regionTotals[x] += (regions[x])[y];
        }
        $("results").textContent += "Region " + (x + 1) + ": " + regionTotals[x] + "\n";
    }
}

var totalSales = function () {
    //$("results").textContent = "total";
    $("results").textContent = ""; //Clear previous button pushes.
    $("results").textContent = "Total Sales" + "\n";
    var totalSales = 0;
    for (var m = 0; m < regions.length; m++) {
        for (var n = 0; n < 4; n++) {
            totalSales += (regions[m])[n];
        }
    }
    $("results").textContent += "# of Regions: " + regions.length + "\n" + "Total Sales: " + totalSales;
}
window.onload = function () {
    $("show_quarter").onclick = quarterSales;
    $("show_region").onclick = regionSales;
    $("show_total").onclick = totalSales;

}


