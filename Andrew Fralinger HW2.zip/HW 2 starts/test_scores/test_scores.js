var names = ["Ben", "Joel", "Judy", "Anne"];
var scores = [88, 98, 77, 88];
var textDisplay;

var $ = function (id) { return document.getElementById(id); }

var addElement = function () {
    // get user entries
    textDisplay = ""; //Clear entries
	var name = $("name").value;
    var score  = parseInt( $("score").value );
    
    // check entries for validity
    if (name == "" || isNaN(score) || score < 0 || score > 100) {
    	alert("You must enter a name and a valid score");
    }
	else {
		names[names.length] = $("name").value;
		scores[scores.length] = parseInt($("score").value);
	    $("name").value = "";
        $("score").value = "";
        alert("Student " + name + " with score " + score + " added!");
        $("results").textContent = textDisplay; //Clear results after adding a name.
    }
    $("name").focus();
}

var bestScore = function () {
    textDisplay = ""; //Clearing the results from previous actions
    textDisplay += "High Score Student(s): ";
    var bestScore = 0;
    var bestIndex = []; //Making a best index array, to handle multiple people having the same best score.
    for (var x = 0; x < scores.length; x++) {
        if (scores[x] > bestScore)
            bestScore = scores[x];
    }
    for (var y = 0; y < scores.length; y++) {
        //There's probably a more concise way to do this rather than using 2 loops
        //but at the moment I can't think of it.
        if (scores[y] == bestScore)
            bestIndex[bestIndex.length] = y; //Now I have a list of the indicies that contain all copies of the best scores (If there are any)
    }
    for (var z = 0; z < bestIndex.length; z++) {
        textDisplay += names[bestIndex[z]] + " ";
    }
    textDisplay += "\n" + "High Score: " + bestScore;
    $("results").textContent = textDisplay;
}

var listArray = function () {
    textDisplay = ""; //Clear results
    textDisplay += "All Scores:" + "\n";
    for (var i = 0; i < scores.length; i++){
        textDisplay += names[i] + ", " + scores[i] + "\n";
    }
    $("results").textContent = textDisplay;
}
window.onload = function () {
    $("add").onclick = addElement;
    $("show_best").onclick = bestScore;
    $("list_array").onclick = listArray;
	$("name").focus();
}


