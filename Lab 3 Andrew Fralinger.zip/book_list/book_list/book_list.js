"use strict";
$(document).ready(function () {
    $("#categories a").each(function () {
        var myImage = new Image();
        myImage.src = $(this).attr("href");
    });
    $("#categories h2").click(function (evt) {
        $(this).toggleClass("minus");
        if ($(this).attr("class") !== "minus") {
            $(this).next().hide();
            $("#image").attr("src", ""); //Clear the image if they open/close a tab
        }
        else {
            $(this).next().show();
            $("#image").attr("src", "");//Same as above comment
        }
        evt.preventDefault();
    }); // end click
    $("#categories a").click(function (evt) {
        // swap image
        var imageURL = $(this).attr("href");
        $("#image").attr("src", imageURL);

        // cancel the default action of the link
        evt.preventDefault();  // jQuery cross-browser method
    });
    $("#categories").find("a:first").focus();
}); // end ready
