﻿var player;
function UserCharacter(myClass, hp, atk, luck, gold, level) {
    this.className = myClass;
    this.hitPoints = hp;
    this.attack = atk;
    this.lucky = luck;
    this.money = gold;
    this.myLevel = level;
}

var playerExplorer = function () {
    if ($("#userName").val() == "") {
        alert("You must enter your name");
        $("#userName").focus();
    }
    else {
        //alert("You have chosen Explorer!");
        player = new UserCharacter("Explorer", 10, 5, true, 100, 0);
        storyStart();
    }
     
}

var playerFighter = function () {
    if ($("#userName").val() == "") { 
        alert("You must enter your name");
        $("#userName").focus();
}
    else {
        //alert("You have chosen Fighter!");
        player = new UserCharacter("Fighter", 10, 8, false, 100, 0);
        storyStart();
    }
}

var playerPriest = function () {
    if ($("#userName").val() == "") {
        alert("You must enter your name");
        $("#userName").focus();
    }
    else {
        //alert("You have chosen Priest!");
        player = new UserCharacter("Priest", 15, 3, false, 250, 0);
        storyStart();
    }
}
function printStats () {
    $("#playerName").text($("#userName").val());
    $("#playerClass").text(player.className);
    $("#playerHP").text(player.hitPoints);
    $("#playerATK").text(player.attack);
    $("#playerGold").text(player.money);
    $("#playerLvl").text(player.myLevel);
}
var storyStart = function () {
    //console.log('hello');
    document.getElementById("startMenuTrack").pause();
    document.getElementById("mainGameTrack").play();
    $(".startMenu").css('display', 'none');
    $(".storyBits").css('display', 'block');
    $("#mystats").css('display', 'inline-block');
    $(".stats").css('display', 'inline');
    $(".pyramids").css('display', 'block');
    $("#storyText").text("The Year is 1925.  You are a lowly " + player.className + " named " + $("#userName").val() + " who has traveled to Cairo, " +
        "Egypt as part of an excavation party headed up by the wealthy eccentric Sir Hudson Campbell.  You are exploring " +
        "the tomb of the ancient pharaoh Akhetamun.  Legends say that the tomb is cursed.  Could they be true?");
    printStats();
    //$("#btnContinue").click(choice);
}

var storyContinue = function () {
    //console.log("in storyContinue");
    //console.log(player);
    $(".resultBits").css('display', 'none');
    $(".storyBits").css('display', 'block');
    var storylines = '{"storySegments": [' +
        '{"level": "1", "story": "Delving deeper into the darkness, you recall your initial meeting with Sir Campbell.  Were it not for him, you would still be in that tavern in Derbyshire.  As you begin your descent, you are glad for his sponsorship.  This really could be the big one!"},' +
        '{"level": "2", "story": "\'Over There!\' Campbell cries!  You immediately turn your head, readying yourself for unimaginable gold. \'Look at this wondrous specimen!\' Campbell hands you a small brown scarab beetle.  You groan."},' +
        '{"level": "3", "story": "It must be the heat of the suffocating tomb affecting your senses.  You swear you hear a faint, low, ethereal moaning sound coming from ahead of the party.  Surely nobody went in before Campbell and yourself.  As you turn back, you realize that the rest of the party has vanished. \'Hello!?\' you shout, to no avail.  As you turn back towards the tomb, you realize that Campbell has gone as well.  You are alone.  It is deathly quiet."},' +
        '{"level": "4", "story": "As you continue your quiet descent through the silent, ancient labyrinth, you recall the stories of Akhetamun.  Your mind won\'t let you believe it, but your eyes and ears seem to betray even your mind.  Is this tomb really cursed?  As you think this, you hear a low rumbling sound from the walls around you.  A sound like laughter erupts from all around you.  Smoke is emanating from somewhere ahead.  There\'s no denying it.  The curse is real.  The pharaoh\'s tomb lies ahead."},' +
        '{"level": "5", "story": "You finally approach the legendary pharaoh\'s tomb.  The smoke is suffocating, but you can faintly make out the hieroglyphs on the wall.  As you step into the room, you realize that you can make out the engravings because they are actually glowing.  A low, pulsating green light surrounds you.  You then realize that you are before the sarcophagus itself.  Akhetamun\'s resting place slowly slides open, revealing a grotesque humanlike form.  The figure immediately turns to you, and laughs the same low rumbling laugh from earlier."},' +
        '{"level": "6", "story": "\'Foolish mortal!  There is nothing you can do now!\' You have to act quickly.  You remember from your studies that if the curse were real, its power would only extend to the tomb itself, unless the pharaoh were to escape.  You must escape and seal the tomb before it\'s too late."},' +
        '{"level": "7", "story": "As you continue your exhausting run, you begin to notice that the walls are becoming lighter.  You are getting close!  Akhetamun is still behind you, and you can sense that he is enraged.  You dare not turn around.  All of your energy has to go to completing your task.  The fate of the world could depend on it."},'+
        '{"level": "8", "story": "Despite your best efforts, the curse of Akhetamun has overtaken you.  You have died.  Game over."},' +
        '{"level": "9", "story": "As you sprint out the front of the tomb, you spy to your right Campbell and the rest of the party!  They made it out!  You shout for their assistance as you begin to push the huge stone in front of the tomb entrance.  The rest of the party rushes to your side as you see Akhetamun from just the other side of the entrance.  With your combined effort, you re-seal the tomb, and all of you hear the ear-splitting scream of the ancient pharaoh as he was trapped.  As is the nature of these curses, with the tomb re-sealed, Akhetamun decomposed, returned to his mortal state.  You look to Campbell \'What did you find down there?\' he cried.  You chuckle to yourself.  He and the others must\'ve gotten lost before even getting close. \'Something a little more interesting than scarabs\' you reply.  \'I think we\'ve made that big discovery you were hoping for, Your Excellency.\'  You Win!"}' +
            ']}';
        var myStoryline = JSON.parse(storylines);
        var count = Object.keys(myStoryline.storySegments).length;
        player.myLevel++;
        //console.log(player.myLevel);
        printStats();
        if (player.hitPoints <= 0) {
            //You lose!  Game over
            $("#btnContinue").css('display', 'none');
            $("#mystats").css('display', 'none');
            $(".playAgain").css('display', 'block');
            //console.log("Game Over.");
            document.getElementById("mainGameTrack").pause();
            document.getElementById("gameOverJingle").play();
            $("#storyText").text(myStoryline.storySegments[7].story);
        }
        else if (player.myLevel == 4) {
            //Play out boss battle
            //Boss battle is going to be automated, only due to a lack of time to fully implement it.  Basically, in this version of the game, if you get here, you win automatically!
            //console.log("Boss Fight!");
            document.getElementById("mainGameTrack").pause();
            document.getElementById("finalBossTrack").play();
            $("#btnContinue").css('display', 'none');
            $(".bossButton").css('display', 'block');
            $("#storyText").text(myStoryline.storySegments[player.myLevel].story);
            $("#btnBossFight").unbind().click(function bossBattle() {
                player.myLevel = player.myLevel + 1;
                if (player.myLevel == 7) {
                    var score = player.money;
                    if (player.className == "Fighter") {
                        score = score * 2;
                    }
                    else if (player.className == "Priest") {
                        score = score * 3;
                    }
                    $(".bossButton").css('display', 'none');
                    $("#mystats").css('display', 'none');
                    $(".playAgain").css('display', 'block');
                    $(".victory").css('display', 'block');
                    document.getElementById("finalBossTrack").pause();
                    document.getElementById("victoryTheme").play();
                    $("#storyText").text(myStoryline.storySegments[8].story);
                    $("#storyText").append("<br /><br /><strong>Your final score is " + score + "!</strong>");
                }
                else {
                    $("#storyText").text(myStoryline.storySegments[player.myLevel].story);
                }
                return;
            });
        }
        else {
            for (var x = 0; x < count; x++) {
                if (parseInt(myStoryline.storySegments[x].level) == player.myLevel) {
                    $("#storyText").text(myStoryline.storySegments[x].story);
                }
            }
        }
        //$("#btnContinue").click(choice);  Commenting out, because I think since I bound it up above, it doesn't need to be bound again.  I was getting multiple calls to choice at once, and they grew exponentially.
}

var choice = function () {
    //alert("Let's make a choice!");
    $(".storyBits").css('display', 'none');
    $(".pyramids").css('display', 'none');
    $(".choiceBits").css('display', 'block');
    var choiceJSON = '{"choices": [' +
        '{"level": "0", "choice": "As you enter the tomb, you see a crossroads ahead.  Given your studies, you know that the sarcophagus chamber lies to the east of the main entrance.  In addition, you know that these tombs tend to have many false passageways with traps for greedy graverobbers.", "firstChoice": "Take the eastern path", "firstChoiceGood": "good", "secondChoice": "Take the western path", "secondChoiceGood": "bad"},' +
        '{"level": "1", "choice": "Beyond the entrance fork, you are not sure as to where to go.  You see yet another fork in the path.  This tomb is clearly a labyrinth.  To your right, you see nothing but darkness.  To your left, you hear some sort of undefinable sounds.  Animals, perhaps?", "firstChoice": "Go right", "firstChoiceGood": "bad", "secondChoice": "Go left", "secondChoiceGood": "good"},' +
        '{"level": "2", "choice": "The deeper you go, the darker it gets.  And yet, your eyes are slowly becoming accustomed to the darkness.  You hear in the darkness ominous sounds from both paths ahead.  Clearly whatever is down here is not happy to see you.", "firstChoice": "Go left", "firstChoiceGood": "awful", "secondChoice": "Go right", "secondChoiceGood": "bad"},' +
        '{"level": "3", "choice": "Alone and afraid, you realize that you have to continue forward.  You seem to have solved the labyrinth, as there is only one path ahead, now.  Surprisingly, you see a faint light in the distance.  Whatever is going on here, you will figure this out.  You know that a tough fight is likely ahead.", "firstChoice": "Approach the light", "firstChoiceGood": "awful", "secondChoice": "Approach the light", "secondChoiceGood": "awful"}' +
        ']}';
    var enemiesJSON = '{"enemies": [' +
        '{"enemy": "Bat", "HP": "5", "ATK": "2", "level": "1"},' +
        '{"enemy": "Giant Scarab", "HP": "8", "ATK": "1", "level": "1"},' +
        '{"enemy": "Cobra","HP": "12", "ATK": "3", "level": "2"},' +
        '{"enemy": "Rat Horde", "HP": "5", "ATK": "6", "level": "2"},' +
        '{"enemy": "Mummified Servant", "HP": "25", "ATK": "2", "level": "3"}' +
        ']}';
    var trapsJSON = '{"traps": [' +
        '{"trapType": "Spike Trap", "damage": "3", "level": "1"},' +
        '{"trapType": "Hieroglyph Puzzle", "damage": "1", "level": "1"},' +
        '{"trapType": "Giant Boulder","damage": "7","level": "2"},' +
        '{"trapType": "Poison Arrows", "damage": "5", "level": "2"}' +
        ']}';
    var shopJSON = '{"shop": [' +
        '{"item": "bandage", "stat": "HP", "boost": "5", "cost": "50" },' +
        '{"item": "sword", "stat": "ATK", "boost": "1", "cost": "50"}' +
        ']}';
    /*$.getJSON('choices.json', {}, function(data) {
        console.log(data);
    });*/ //Getting JSON wouldn't work for me, so I resorted to the caveman approach, above, putting my JSON into a variable.  I know it's bad practice, but it works.  Will revisit at a later time.
    /*$.ajax({
        url: 'choices.json',
        dataType: 'json',
        type: 'get',
        cache: false,
        success: function (data) {
            console.log(data);
        }
    });*/
    var myChoices = JSON.parse(choiceJSON);
    var myEnemies = JSON.parse(enemiesJSON);
    var myTraps = JSON.parse(trapsJSON);
    var myShop = JSON.parse(shopJSON);
    //console.log(player.myLevel);
    //console.log(myChoices.choices[0].choice);
    var count = Object.keys(myChoices.choices).length; //Used to get the length of the JSON, as it doesn't naturally have length.
    //console.log(count);
    //console.log(myChoices.length);
    var currentChoice = 0; //Gets the index of the current level in order to continue handling the choice.
    for (var i = 0; i < count; i++){
        if (myChoices.choices[i].level == player.myLevel) {
            $("#choiceText").text(myChoices.choices[i].choice);
            $("#firstChoice").text(myChoices.choices[i].firstChoice);
            $("#secondChoice").text(myChoices.choices[i].secondChoice);
            currentChoice = i;
            //console.log(myChoices.choices[i].choice);
        }
    }
    //console.log(currentChoice);
    //console.log(player);
    $("#firstChoice").unbind().click(function choice1() {
        $(".choiceBits").css('display', 'none');
        $(".resultBits").css('display', 'block');
        var choiceWheel = 0;
        choiceWheel = Math.floor((Math.random() * 10) + 1); //Pick a random number between 1 and 10, which will determine if the outcome is good or bad.  Higher is better!
        if (player.lucky) {
            choiceWheel = choiceWheel + 2; //Explorers get a 20% boost, towards finding better outcomes!
        }
        if (myChoices.choices[currentChoice].firstChoiceGood == "good") {
            if (choiceWheel <= 5) {
                //Nothing Happens
                //console.log("firstChoice good nothing");
                $("#resultText").text("As you progress down the dark corridors, you find nothing of note.");
                return;
                //console.log("Nothing");
            }
            else if (choiceWheel > 5 && choiceWheel <= 8) {
                //Trade!  You trade some gold to buy a boost
                //console.log("Shop");
                //console.log("firstChoice good trade");
                if (player.money > 50) {
                    var coinFlip = Math.round(Math.random());
                    $("#resultText").text("\"Old chap, you don't look so good!  Here, take this gift!  For a price, of course.\"  You recieve a " + myShop.shop[coinFlip].item + ", boosting your " + myShop.shop[coinFlip].stat + " by " + myShop.shop[coinFlip].boost + ".  You give Sir Campbell " + myShop.shop[coinFlip].cost + " gold.");
                    player.money = player.money - parseInt(myShop.shop[coinFlip].cost);
                    if (myShop.shop[coinFlip].stat == "HP") {
                        player.hitPoints = player.hitPoints + 5;
                        printStats();
                        return;
                    }
                    else {
                        player.attack = player.attack + 1;
                        printStats();
                        return;
                    }
                }
                else {
                    //Nothing Happens
                    $("#resultText").text("As you progress down the dark corridors, you find nothing of note.");
                    return;
                }
            }
            else if (choiceWheel > 8) {
                //Treasure!  Get gold!
                //console.log("Treasure");
                //console.log("firstChoice good treasure");
                $("#resultText").text("As you traverse the seemingly endless caverns, a golden glint catches your eye.  You find a long lost gold vein!  A share of the former king's treasure trove!  Gain 100 gold.");
                player.money = player.money + 100;
                printStats(); //I'll reprint the stats any time one changes.
                return;
            }
        }
        else if (myChoices.choices[currentChoice].firstChoiceGood == "bad") {
            //do bad stuff
            if (choiceWheel <= 5) {
                //console.log("firstChoice bad trap");
                //Trap!  Lose stuff with no chance of beating it.
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level trap: Spikes or Puzzle
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random high-level trap: Boulder or Poison Arrows
                    coinFlip = coinFlip + 2;
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                return;
            }
            else if (choiceWheel > 5 && choiceWheel <= 8) {
                //Monster!  Fight a random monster based on your level!
                //console.log("firstChoice bad monster");
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level monster: Bats or Scarab
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random mid-level monster: Cobra or Rat Horde
                    coinFlip = coinFlip + 2;
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");   
                    printStats();
                }
                return;
            }
            else if (choiceWheel > 8) {
                //console.log("firstChoice bad nothing");
                //Nothing Happens.  Best outcome!
                $("#resultText").text("As you progress down the dark corridors, you find nothing of note.");
                //console.log("Nothing");
                return;
            }
        }
        else {
            //do very bad stuff
            if (choiceWheel <= 5) {
                //console.log("firstChoice awful big monster");
                //Fight a super tough monster!
                var myMonster = myEnemies.enemies[4];
                myMonster.HP = parseInt(myMonster.HP);
                myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                var damage = 0;
                while (player.hitPoints > 0 && myMonster.HP > 0) {
                    //player attacks first
                    myMonster.HP = (myMonster.HP - player.attack);
                    if (myMonster.HP > 0) {
                        //If the monster is not dead, it gets a retaliatory attack
                        player.hitPoints = (player.hitPoints - myMonster.ATK);
                        damage = damage + myMonster.ATK;
                    }
                }
                $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                printStats();
                return;
            }
            else if (choiceWheel > 5 && choiceWheel <= 8) {
                //Trap!
                //console.log("firstChoice awful trap");
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level trap: Spikes or Puzzle
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random high-level trap: Boulder or Poison Arrows
                    coinFlip = coinFlip + 2;
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                return;
            }
            else if (choiceWheel > 8) {
                //Fight a regular monster
                //console.log("firstChoice awful monster");
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level monster: Bats or Scarab
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random mid-level monster: Cobra or Rat Horde
                    coinFlip = coinFlip + 2;
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                return;
            }
        }
    });
    $("#secondChoice").unbind().click(function choice2() {
        $(".choiceBits").css('display', 'none');
        $(".resultBits").css('display', 'block');
        var choiceWheel = 0; //refresh the random number before each choice.
        choiceWheel = Math.floor((Math.random() * 10) + 1); //Pick a random number between 1 and 10, which will determine if the outcome is good or bad.  Higher is better!
        //console.log(choiceWheel);
        if (player.lucky) {
            choiceWheel = choiceWheel + 2; //Explorers get a 20% boost!
        }
        //console.log(choiceWheel);
        if (myChoices.choices[currentChoice].secondChoiceGood == "good") {
            if (choiceWheel <= 5) {
                //Nothing Happens
                //console.log("secondChoice good nothing");
                $("#resultText").text("As you progress down the dark corridors, you find nothing of note.");
                return;
            }
            else if (choiceWheel > 5 && choiceWheel <= 8) {
                //Shop!  You can trade gold to buy a boost
                //console.log("secondChoice good trade");
                if (player.money > 50) {
                    var coinFlip = Math.round(Math.random());
                    $("#resultText").text("\"Old chap, you don't look so good!  Here, take this gift!  For a price, of course.\"  You recieve a " + myShop.shop[coinFlip].item + ", boosting your " + myShop.shop[coinFlip].stat + " by " + myShop.shop[coinFlip].boost + ".  You give Sir Campbell " + myShop.shop[coinFlip].cost + " gold.");
                    player.money = player.money - parseInt(myShop.shop[coinFlip].cost);
                    if (myShop.shop[coinFlip].stat == "HP") {
                        player.hitPoints = player.hitPoints + 5;
                        printStats();
                        return;
                    }
                    else {
                        player.attack = player.attack + 1;
                        printStats();
                        return;
                    }
                }
                else {
                    //Nothing Happens
                    $("#resultText").text("As you progress down the dark corridors, you find nothing of note.");
                    return;
                }
            }
            else if (choiceWheel > 8) {
                //Treasure!  Get a free boost!
                //console.log("secondChoice good treasure");
                $("#resultText").text("As you traverse the seemingly endless caverns, a golden glint catches your eye.  You find a long lost gold vein!  A share of the former king's treasure trove!  Gain 100 gold.");
                player.money = player.money + 100;
                printStats();
                return;
            }
        }
        else if (myChoices.choices[currentChoice].secondChoiceGood == "bad") {
            //console.log(choiceWheel);
            if (choiceWheel <= 5) {
                //console.log("secondChoice bad trap");
                //Trap!  Lose stuff with no chance of beating it.
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level trap: Spikes or Puzzle
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    //console.log("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random high-level trap: Boulder or Poison Arrows
                    coinFlip = coinFlip + 2;
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                return;
            }
            else if (choiceWheel > 5 && choiceWheel <= 8) {
                //console.log("secondChoice bad monster");
                //Monster!  Fight a random monster based on your level! 
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level monster: Bats or Scarab
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random mid-level monster: Cobra or Rat Horde
                    coinFlip = coinFlip + 2;
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                return;
            }
            else if (choiceWheel > 8) {
                //Nothing Happens.  Best outcome!
                //console.log("nothing happens");
                //console.log("secondChoice bad nothing");
                $("#resultText").text("As you progress down the dark corridors, you find nothing of note.");
                return;
            }
        }
        else {
            if (choiceWheel <= 5) {
                //Fight a super tough monster!
                //console.log("secondChoice awful big monster");
                var myMonster = myEnemies.enemies[4];
                myMonster.HP = parseInt(myMonster.HP);
                myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                var damage = 0;
                while (player.hitPoints > 0 && myMonster.HP > 0) {
                    //player attacks first
                    myMonster.HP = (myMonster.HP - player.attack);
                    if (myMonster.HP > 0) {
                        //If the monster is not dead, it gets a retaliatory attack
                        player.hitPoints = (player.hitPoints - myMonster.ATK);
                        damage = damage + myMonster.ATK;
                    }
                }
                $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                printStats();
                return;
            }
            else if (choiceWheel > 5 && choiceWheel <= 8) {
                //Trap!
                //console.log("secondChoice awful trap");
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level trap: Spikes or Puzzle
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random high-level trap: Boulder or Poison Arrows
                    coinFlip = coinFlip + 2;
                    $("#resultText").text("You have triggered a " + myTraps.traps[coinFlip].trapType + " trap!  You take " + myTraps.traps[coinFlip].damage + " damage.");
                    player.hitPoints = player.hitPoints - parseInt(myTraps.traps[coinFlip].damage);
                    printStats();
                }
                return;
            }
            else if (choiceWheel > 8) {
                //Fight a regular monster
                //console.log("secondChoice awful monster");
                var coinFlip = Math.round(Math.random());
                if (player.myLevel < 2) {
                    //Encounter a random low-level monster: Bats or Scarab
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                else if (player.myLevel >= 2) {
                    //Encounter a random mid-level monster: Cobra or Rat Horde
                    coinFlip = coinFlip + 2;
                    var myMonster = myEnemies.enemies[coinFlip];
                    myMonster.HP = parseInt(myMonster.HP);
                    myMonster.ATK = parseInt(myMonster.ATK); //Parsing both values here, so I don't have to keep doing it later.
                    var damage = 0;
                    while (player.hitPoints > 0 && myMonster.HP > 0) {
                        //player attacks first
                        myMonster.HP = (myMonster.HP - player.attack);
                        if (myMonster.HP > 0) {
                            //If the monster is not dead, it gets a retaliatory attack
                            player.hitPoints = (player.hitPoints - myMonster.ATK);
                            damage = damage + myMonster.ATK;
                        }
                    }
                    $("#resultText").text("You encountered a " + myMonster.enemy + "!  You take " + damage + " damage in defeating it.");
                    printStats();
                }
                return;
            }
        }
    });
    //$("#btnReturnToStory").click(storyContinue);
    //Need return statements to get out of choice1 and choice2
}

window.onload = function() {
    document.getElementById("startMenuTrack").play(); //To hear the audio on page load, you must set the Autoplay Policy flag in Chrome to "No User Gesture is Required".  This way, media can play without user input.
    $("#playerExplorer").click(playerExplorer);
    $("#playerFighter").click(playerFighter);
    $("#playerPriest").click(playerPriest);
    $("#btnContinue").click(choice);
    $("#btnReturnToStory").click(storyContinue);
    //$("#btnPlayAgain").click(window.location.reload());
    $("#userName").focus();
}